package msclookup;


import java.io.File;
import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Predicate;

import atu.testng.reports.ATUReports;
import atu.testng.reports.logging.LogAs;
import atu.testng.selenium.reports.CaptureScreen;
import atu.testng.selenium.reports.CaptureScreen.ScreenshotOf;



/**
 * @author Jan 19, 2017
 *
 */
public class CoreWrapper {



	protected static WebDriver driver;

	protected static String testCaseName;
	protected static String testDescription;

	Select dropdown;

	Alert alert;
	int i=1;

	final String xpath= "XPATH";
	final String id= "ID";
	final String name= "NAME";
	final String linktext= "LINKTEXT";

	DesiredCapabilities dc = new DesiredCapabilities();
	public void launchApp(String URL,String browser) throws IOException{

		try{
			
			ATUReports.setWebDriver(driver);
			ATUReports.indexPageDescription = "MSC NDC Lookup Automation";
			
			if(browser.equalsIgnoreCase("chrome")){
				System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
				driver = new ChromeDriver();
			}
			if(browser.equalsIgnoreCase("IE")){
				System.setProperty("webdriver.ie.driver", "./IEDriverServer.exe");
				driver = new InternetExplorerDriver();
			}
			
			if(browser.equalsIgnoreCase("firefox")){
				
				driver = new FirefoxDriver();
			}

			driver.manage().window().maximize();
			driver.get(URL);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

			//ATUReports.add(" Browser launched Successfully", LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}catch(Exception e){
			//ATUReports.add("Unable to launch ", LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}
	}

	public void waitFor(int secs){

		try{
			Thread.sleep(secs);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public boolean Waituntil(String fin_xpath,int secs){
		boolean Alert = false;
		try{ 
			WebDriverWait wait = new WebDriverWait(driver, secs);
			WebElement A =wait.until(ExpectedConditions.elementToBeClickable(By.xpath(fin_xpath)));
			if (A == null){Alert = false;}
			else if (A != null){Alert = true;}
		}catch(Exception e){
			e.printStackTrace();
		}
		return Alert;
	}
	
	public void enterValById(String loc_id, String value) throws IOException{

		try{
			driver.findElement(By.id(loc_id)).sendKeys(value);
			waitFor(500);
			ATUReports.add("Value entered in "+loc_id+" as "+value, LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}catch(Exception e){
			ATUReports.add("Unable to find "+loc_id, LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}
	}
	
	public void clearValById(String loc_id) throws IOException{

		try{
			driver.findElement(By.id(loc_id)).clear();
			waitFor(500);
			ATUReports.add("Value entered in "+loc_id+" as ", LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}catch(Exception e){
			ATUReports.add("Unable to find "+loc_id, LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}
	}
	public void clearValByXpath(String loc_xpath) throws IOException{

		try{
			driver.findElement(By.xpath(loc_xpath)).clear();
			waitFor(500);
			ATUReports.add("Value entered in "+loc_xpath, LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}catch(Exception e){
			ATUReports.add("Unable to find "+loc_xpath, LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}
	}

	public void enterValByName(String loc_name, String value) throws IOException{

		try{
			driver.findElement(By.name(loc_name)).sendKeys(value);
			waitFor(500);
			ATUReports.add("Value entered in "+loc_name, LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));

		}catch(Exception e){
			ATUReports.add("Unable to find "+loc_name, LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));

		}
	}

	public void enterValByXpath(String loc_name, String value) throws IOException{

		try{
			driver.findElement(By.xpath(loc_name)).sendKeys(value);
			waitFor(500);
			ATUReports.add("Value entered in "+loc_name+" as "+value, LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));

		}catch(Exception e){
			ATUReports.add("Unable to find "+loc_name, LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}
	}
		
	public void enterValByClassname(String loc_class, String value) throws IOException{

			try{
				driver.findElement(By.className(loc_class)).sendKeys(value);
				waitFor(500);
				ATUReports.add("Value entered in "+loc_class+" as "+value, LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));

			}catch(Exception e){
				ATUReports.add("Unable to find "+loc_class, LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));
			}
			//		screenShot();
	}

	public void clickById(String loc_id) throws IOException{
		try{
			driver.findElement(By.id(loc_id)).click();
			ATUReports.add(loc_id+" is clicked", LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}catch(Exception e){
			ATUReports.add("Unable to click "+loc_id, LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}

	}

	public void clickByName(String loc_name) throws IOException{

		try{
			driver.findElement(By.name(loc_name)).click();
			ATUReports.add(loc_name+" is clicked", LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}catch(Exception e){
			ATUReports.add("Unable to click "+loc_name, LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}


	}	

	public void clickByXpath(String loc_name) throws IOException{

		try{
			
			driver.findElement(By.xpath(loc_name)).click();
			
			ATUReports.add(loc_name+" is clicked", LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));

		}catch(Exception e){
			ATUReports.add("Unable to click "+loc_name, LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}
	}	
	
	public void screenShot() throws IOException{



		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

		//FileUtils.copyFile(src, new File("D:\\Anil\\Anil\\material\\Selenium\\Snapshots\\snap"+i+".jpg"));
		FileUtils.copyFile(src, new File("C:\\Users\\EE6516\\Pictures"+i+".jpg"));

		i= i+1;

	}

	public void selectByText(String loc_path,String text ){

		try{
			dropdown = new Select(driver.findElement(By.xpath(loc_path)));
			dropdown.selectByVisibleText(text);
			ATUReports.add("Dropdown value with "+text+" is selected", LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}catch(Exception e){
			ATUReports.add("Unable to select the dropdown value "+text, LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}

	}

	public void selectByIndex(String loc_name,int index ){

		try{
			dropdown = new Select(driver.findElement(By.name(loc_name)));
			dropdown.selectByIndex(index);
			ATUReports.add("Dropdown value is selected", LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}catch(Exception e){
			ATUReports.add("Unable to select the Dropdown value", LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}

	}

	public void closeAllBrowsers(){

		driver.quit();

	}

	public void swithchToPrimaryWindow(){
		int handlecount =0;
		Set<String> handles = driver.getWindowHandles();

		for (String handle : handles) {

			handlecount = handlecount+1;

			if(handlecount ==1){

				driver.switchTo().window(handle);

				break;
			}
		}
	}

	public void swithchToLastWindow(){

		Set<String> handles = driver.getWindowHandles();

		for (String handle : handles) {

			driver.switchTo().window(handle);
		}
	}

	public void switchToFrameByElement(String loc_id){
		driver.switchTo().frame(driver.findElement(By.id(loc_id)));
	}	

	public void switchToFrameByClass(String class_name){
		driver.switchTo().frame(driver.findElement(By.className(class_name)));
	}

	public void switchToFirstFrame(String loc_id){
		driver.switchTo().frame(0);
	}	

	public void alertAccept(){
		alert = driver.switchTo().alert();
		alert.accept();

	}

	public void alertDismiss(){
		alert = driver.switchTo().alert();
		alert.dismiss();

	}

	public void verifyText(String loc_xpath, String textval){
		String text = null;
		try{
			text = driver.findElement(By.xpath(loc_xpath)).getText();
			if(text.equals(textval)){
				System.out.println("Expected text::  "+textval);
				System.out.println("Actual text::  "+text);
				System.out.println("Expected text==Actual text");
				waitFor(5000);

			} else{
				System.out.println("miss matched text found");
			}
			ATUReports.add(text+" "+textval+" Matches", LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}catch(Exception e){
			ATUReports.add(text+" "+textval+" not matches", LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}
	}
	public void verifyUrl(String URL){


		String browser_url = driver.getCurrentUrl();

		if(URL.equals(browser_url)){

			System.out.println("Expected URL::  "+URL);
			System.out.println("Actual text::  "+browser_url);
			System.out.println("Both URL's are equal");
		} else{

			System.out.println("miss matched URL's found");
		}
	}
	public void enterText(String type, String locator, String value){
		
		try{
			if(type.equalsIgnoreCase(xpath)){	

				driver.findElement(By.xpath(locator)).sendKeys(value);

			}
			if(type.equalsIgnoreCase(id)){	

				driver.findElement(By.id(locator)).sendKeys(value);

			}
			if(type.equalsIgnoreCase(linktext)){	

				driver.findElement(By.linkText(locator)).sendKeys(value);

			}
			if(type.equalsIgnoreCase(name)){	

				driver.findElement(By.name(locator)).sendKeys(value);

			}
			ATUReports.add("Element located by "+type+" and value entered is "+value, LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}catch(Exception e){
			ATUReports.add("Unable to locate the element with "+type+"::"+locator, LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));

		}
		
	}

	public void click(String type, String locator){

		try{
			if(type.equalsIgnoreCase(xpath)){	

				driver.findElement(By.xpath(locator)).click();

			}
			if(type.equalsIgnoreCase(id)){	

				driver.findElement(By.id(locator)).click();

			}
			if(type.equalsIgnoreCase(linktext)){	

				driver.findElement(By.linkText(locator)).click();

			}
			if(type.equalsIgnoreCase(name)){	

				driver.findElement(By.name(locator)).click();

			}
			ATUReports.add("Element located by "+type+" and performed click action ", LogAs.PASSED, new CaptureScreen(ScreenshotOf.DESKTOP));
		}catch(Exception e){
			ATUReports.add("Unable to locate element with "+type+"::"+locator, LogAs.FAILED, new CaptureScreen(ScreenshotOf.DESKTOP));

		}
	}
	public void closeBrowser(){
		driver.close();
	}
}
