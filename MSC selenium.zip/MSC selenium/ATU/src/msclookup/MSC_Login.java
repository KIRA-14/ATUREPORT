package msclookup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import msclookup.MSC_Login;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.Wait;

import atu.testng.reports.ATUReports;
import atu.testng.reports.listeners.ATUReportsListener;
import atu.testng.reports.listeners.ConfigurationListener;
import atu.testng.reports.listeners.MethodListener;


@Listeners({ATUReportsListener.class,ConfigurationListener.class,MethodListener.class})

public class MSC_Login 
{
	{
		System.setProperty("atu.reporter.config", "atu.properties");
	}
	static  CoreWrapper obj;
	static Properties prop;

//*Data from Properties 
	public static  Properties myData() throws Exception, IOException {
		prop = new Properties();
		prop.load(new FileInputStream(new File("C:\\esi-sofea\\ws\\MSC\\Input\\DataFile")));
		return prop;}

//*Path from Properties 	
	public static  Properties MSC_Path() throws Exception, IOException {
			prop = new Properties();
			prop.load(new FileInputStream(new File("C:\\esi-sofea\\ws\\MSC\\Input\\Xpath")));
			return prop;}

//*MSC_Login. 

public static void MSC_LOGIN() throws Exception {

	Properties data = MSC_Login.myData();
		String url = data.getProperty("URL");
			obj = new CoreWrapper();
			obj.launchApp(url, data.getProperty("BrowserName"));
			obj.enterValByName("username", data.getProperty("Userid"));
			obj.enterValByName("password",data.getProperty("Password"));
			obj.clickByName("submit");}


public static void NDC_Lookup() throws Exception {
	Properties data = MSC_Login.myData();
	Properties path = MSC_Login.MSC_Path();
		String role= data.getProperty("Role");
		String[] Swichrole=role.split(",");
			for(String val:Swichrole){
				obj.selectByIndex("roleList", Integer.valueOf(val));
						if(Integer.valueOf(val) <= 16){ 
							String Memcomm = data.getProperty("Memcomm_MD") ;
							obj.Waituntil("//*[@name='searchClaimButton']", 5);
							obj.clickByXpath(path.getProperty("Clear"));
							obj.enterValByName("memcomm",Memcomm);}
						else if (Integer.valueOf(val) == 17 || Integer.valueOf(val) <= 38){
							String Memcomm = data.getProperty("Memcomm_CO") ;
							obj.Waituntil("//*[@name='searchClaimButton']", 5);
							obj.clickByXpath(path.getProperty("Clear"));
							obj.enterValByName("memcomm",Memcomm);}
						else if (Integer.valueOf(val) == 39 || Integer.valueOf(val) <= 46){
							String Memcomm = data.getProperty("Memcomm_PA") ;
							obj.Waituntil("//*[@name='searchClaimButton']", 5);
							obj.clickByXpath(path.getProperty("Clear"));
							obj.enterValByName("memcomm",Memcomm);}
						else if (Integer.valueOf(val) == 47 || Integer.valueOf(val) <= 54){
							String Memcomm = data.getProperty("Memcomm_MC");
							obj.Waituntil("//*[@name='searchClaimButton']", 5);
							obj.clickByXpath(path.getProperty("Clear"));
							obj.enterValByName("memcomm",Memcomm);}
						else if (Integer.valueOf(val) == 61 || Integer.valueOf(val) <= 63){
							String Memcomm = data.getProperty("Memcomm_MC");
							obj.Waituntil("//*[@name='searchClaimButton']", 5);
							obj.clickByXpath(path.getProperty("Clear"));
							obj.enterValByName("memcomm",Memcomm);}
			obj.clickByName("searchClaimButton");
			obj.clickByXpath(path.getProperty("Select"));
						if(obj.Waituntil(path.getProperty("Alert"), 5)){
							obj.clickByXpath(path.getProperty("Alert"));}
			obj.clickByXpath(path.getProperty("Claimentry"));
			obj.clickByXpath(path.getProperty("NDC_m"));
			obj.clickByXpath(path.getProperty("NDC_c"));
			obj.enterValByName("drugNDC",data.getProperty("NDC_ID"));
			obj.clickByXpath(path.getProperty("NDC_s"));
			obj.verifyText(path.getProperty("NDC_r"),"Drug NDC");
			obj.clickByXpath(path.getProperty("NDC_c"));
			obj.enterValByName("drugName",data.getProperty("NDC_NM"));
			obj.clickByXpath(path.getProperty("NDC_s"));
			obj.verifyText(path.getProperty("NDC_r"),"Drug NDC");
			obj.clickByXpath(path.getProperty("NDC_c"));
			obj.enterValByName("drugName",data.getProperty("NDC_NM"));
			obj.enterValByName("drugStrength",data.getProperty("NDC_ST"));
			obj.clickByXpath(path.getProperty("NDC_s"));
			obj.verifyText(path.getProperty("NDC_r"),"Drug NDC");
			obj.clickByXpath(path.getProperty("NDC_c"));
			obj.clickByXpath(path.getProperty("Closelookup"));
			obj.clickByXpath(path.getProperty("Workflow"));
		}
	}
}