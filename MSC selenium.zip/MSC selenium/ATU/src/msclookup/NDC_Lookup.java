package msclookup;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;

public class NDC_Lookup {
	
	static  CoreWrapper obj;
	static Properties prop;
@Test
	public void MSC_Login() throws Exception {

		MSC_Login.MSC_LOGIN();}
@Test
	public void NDC_lookup() throws Exception {

		MSC_Login.NDC_Lookup();
		
	}
	
}
